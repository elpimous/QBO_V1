/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEBUG_H
#define __DEBUG_H

#define DEBUG

#ifdef DEBUG

//#define DEBUG_TIM_OUTPUTS
//#define DEBUG_ADC
#define DEBUG_NO_STOP
//#define DEBUG_INFO_USART
//#define TEST_BOARD

#endif

#endif
